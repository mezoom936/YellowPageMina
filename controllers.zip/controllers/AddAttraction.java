package controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AddAttraction")
public class AddAttraction extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public AddAttraction() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Database db = new Database();
		request.setAttribute("attractions", db.getAttractions());
		request.getRequestDispatcher("/WEB-INF/AddAttraction.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		Database db = new Database();
		String name = request.getParameter("name");
		String phoneNumber = request.getParameter("phoneNumber");
		db.addAttraction(name, phoneNumber);
		db.close();
		response.sendRedirect("ListAttractions");	
	}

}
