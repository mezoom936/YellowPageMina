package controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AddReview")
public class AddReview extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public AddReview() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Database db = new Database();
		int id = Integer.parseInt(request.getParameter("id"));
		request.setAttribute("attraction", db.getAttraction(id));
		request.getRequestDispatcher("/WEB-INF/AddReview.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Database db = new Database();
		int id = Integer.parseInt(request.getParameter("id"));
		String reviewer = request.getParameter("reviewer");
		String review = request.getParameter("review");
		db.addReview(reviewer, review, id);
		db.close();
		response.sendRedirect("ListAttractions");
	}

}
