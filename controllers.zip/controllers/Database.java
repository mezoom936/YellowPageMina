package controllers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import models.Attraction;
import models.Review;
import models.Valid;

public class Database {
	
	// Data fields 
		private String url = "jdbc:mysql://127.0.0.1:3306/myschema";
		private Connection connection;
		private String username = "root";
		private String password = "root";
		
		public Database()
		{
			try 
			{
				this.connection = DriverManager.getConnection(this.url, this.username, this.password);
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		
		public void close()
		{
			if(this.connection != null)
			{
				try
				{
					connection.close();
				}
				catch( SQLException e )
		        {
		            e.printStackTrace();
		        }
			}
		}
		
		public List<Attraction> getAttractions()
		{
			List<Attraction> attractions = new ArrayList<>();
			try
			{
				Statement stmt = connection.createStatement();
				String sql = "select a.id, a.name, a.phone from attractions a";
				ResultSet rs = stmt.executeQuery(sql);
				while(rs.next())
				{
					Attraction att = new Attraction();
					att.setId(rs.getInt("id"));
					att.setName(rs.getString("name"));
					att.setPhoneNumber(rs.getString("phone"));
					attractions.add(att);
				}
				stmt.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			return attractions;
		}
		
		public Attraction getAttraction(int id)
		{
			Attraction att = new Attraction();
			try
			{
				String sql = "select a.name, a.phone from attractions a where id = ?";
				PreparedStatement pstmt = connection.prepareStatement(sql);
				pstmt.setInt(1, id);
				ResultSet rs = pstmt.executeQuery();
				if(rs.next())
				{
					att.setName(rs.getString(1));
					att.setPhoneNumber(rs.getString(2));
				}
				pstmt.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			return att;
		}
		
		public void addAttraction(String name, String phoneNumber)
		{	
			try
			{
				String sql = "insert into attractions (name, phone) values (?, ?)";
				PreparedStatement pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, name);
				pstmt.setString(2, phoneNumber);
				pstmt.executeUpdate();
				pstmt.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		
		public void removeAttraction(int id)
		{
			try
			{
				String sql = "delete from attractions where id = ?";
				PreparedStatement pstmt = connection.prepareStatement(sql);
				pstmt.setInt(1, id);
				pstmt.executeUpdate();
				pstmt.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		public List<Review> getReviews(int ida)
		{
			List<Review> reviews = new ArrayList<>();
			try
			{
				String sql = "select reviewer, review from reviews where att_id = " + ida;
				Statement stmt = connection.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery(sql);
				while(rs.next())
				{
					Review review = new Review();
					review.setReviewer(rs.getString(1));
					review.setReview(rs.getString(2));		
					reviews.add(review);
				}
				 stmt.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			return reviews;
		}
		
		public void addReview(String reviewer, String review, int id)
		{
			try
			{
				String sql = "insert into reviews (reviewer, review, att_id) values (?, ?, ?)";
				PreparedStatement pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, reviewer);
				pstmt.setString(2, review);
				pstmt.setInt(3, id);
				pstmt.executeUpdate();
				pstmt.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		
		public void signUp(String username, String password)
		{
			try
			{
				String sql = "insert into valid (username, password) values (?, ?)";
				PreparedStatement pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, username);
				pstmt.setString(2, password);
				pstmt.executeUpdate();
				pstmt.close();
			} 
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		
		public Valid getUser(String username)
		{
			Valid user = new Valid();
			try
			{
				String sql = "select v.username, v.password from valid v where username = ?";
				PreparedStatement pstmt = connection.prepareStatement(sql);
				pstmt.setString(1, username);
				ResultSet rs = pstmt.executeQuery();
				if(rs.next())
				{
					user.setUsername(rs.getString(1));
					user.setPassword(rs.getString(2));
				}
				pstmt.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			return user;
		}
		
		public boolean verifyPassword(String enteredPassword, String storedPasswrord)
		{
			return enteredPassword.equals(storedPasswrord);
		}
		public boolean verifyUsername(String enteredUsername, String storedUsername)
		{
			return enteredUsername.equals(storedUsername);
		}
		
		public List<Valid> getValids()
		{
			List<Valid> valids = new ArrayList<>();
			try
			{
				Statement stmt = connection.createStatement();
				String sql = "select v.id, v.username, v.password from valid v";
				ResultSet rs = stmt.executeQuery(sql);
				while(rs.next())
				{
					Valid v = new Valid();
					v.setId(rs.getInt(1));
					v.setUsername(rs.getString(2));
					v.setPassword(rs.getString(3));
					valids.add(v);
				}
				stmt.close();
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			return valids;
		}
		
//		public Valid getUser2(int id)
//		{
//			Valid user = new Valid();
//			try
//			{
//				String sql = "select v.username, v.password from valid v where id = ?";
//				PreparedStatement pstmt = connection.prepareStatement(sql);
//				pstmt.setInt(1, id);
//				ResultSet rs = pstmt.executeQuery();
//				if(rs.next())
//				{
//					user.setUsername(rs.getString(1));
//					user.setPassword(rs.getString(2));
//				}
//				pstmt.close();
//			}
//			catch(SQLException e)
//			{
//				e.printStackTrace();
//			}
//			return user;
//		}
		
		

}
