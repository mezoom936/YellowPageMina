package controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/GetAttraction")
public class GetAttraction extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public GetAttraction() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Database db = new Database();
		int id = Integer.parseInt(request.getParameter("id"));
		request.setAttribute("reviews", db.getReviews(id));
		request.setAttribute("attraction", db.getAttraction(id));
		request.setAttribute("id", id);
		request.getRequestDispatcher("/WEB-INF/GetAttraction.jsp").forward(request, response);		
	}

}
