package controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import models.Valid;

@WebServlet("/SignIn")
public class SignIn extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public SignIn() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/SignIn.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Database db = new Database();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		request.setAttribute("valids", db.getValids());
		List<String> success = new ArrayList<>();
		Valid user = db.getUser(username);
		request.setAttribute("user", user);
		if (username != null) 
		{
	        if (db.verifyPassword(password, user.getPassword())) 
	        {
	            response.sendRedirect("ListAttractions");
	            db.close();
	            return;
	        }
	    }  
	    String error = "Invalid username or password";
	    request.setAttribute("error", error);
	    request.getRequestDispatcher("/WEB-INF/SignIn.jsp").forward(request, response);
	    db.close();
		
	}

}
