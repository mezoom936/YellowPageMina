package controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import models.Valid;

@WebServlet("/Validation")
public class Validation extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public Validation() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.getRequestDispatcher("/WEB-INF/Validation.jsp").forward(request, response);	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Database db = new Database();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		List<String> errors = new ArrayList<>();
		List<String> success = new ArrayList<>();
		if(username.isEmpty() || password.isEmpty())
		{
			errors.add("All fields are required!");
			
		}
		if(password.length() < 8 || password.length() > 20)
		{
			errors.add("password has to be at least 8 characters!");
		}
		if(!errors.isEmpty())
		{
			request.setAttribute("errors", errors);
			request.getRequestDispatcher("/WEB-INF/Validation.jsp").forward(request, response);
		}
		else
		{
			success.add("Thanks for signing up. Welcome to our community. We are happy to have you on board.");
		}
		if(!success.isEmpty())
		{
			request.setAttribute("success", success);
			db.signUp(username, password);
			db.close();	
		}
		response.sendRedirect("Success");
		
	}

}
